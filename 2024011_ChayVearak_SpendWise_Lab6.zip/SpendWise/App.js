import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, Pressable, Alert, Platform } from 'react-native';

import ScreenHeader from './components/ScreenHeader';
import TotalCard from './components/TotalCard';
import ExpenseItem from './components/ExpenseItem';
import ExpenseForm from './components/ExpenseForm';

export default function App() {
  const [expenses, setExpenses] = useState([
    { id: '1', name: 'Lunch', category: 'Food', amount: '-$4.50' },
    { id: '2', name: 'Grab', category: 'Transport', amount: '-$3.25' },
    { id: '3', name: 'Coffee', category: 'Food', amount: '-$2.00' },
    { id: '4', name: 'Mobile Data', category: 'Utilities', amount: '-$5.00' },
    { id: '5', name: 'Stationery', category: 'Education', amount: '-$9.00' },
  ]);

  // Calculate total spending
  const total = expenses.reduce((sum, expense) => {
    return sum + parseFloat(expense.amount.replace('$', '').replace('-', ''));
  }, 0);

  // Delete function
  const handleDeleteExpense = (idToDelete) => {
    setExpenses(expenses.filter((item) => item.id !== idToDelete));
  };

  const addExpense = (newExpense) => {
    setExpenses((currentExpenses) => [
      newExpense,
      ...currentExpenses,
    ]);
  };

  return (
    <ScrollView style={styles.screen}>
      <View style={styles.container}>
        <ScreenHeader />

        <Text style={styles.sectionTitle}>Monthly Summary</Text>

        <TotalCard
          label="Spent this month"
          amount={`$${Math.abs(total).toFixed(2)}`}
        />

        <TotalCard label="Budget left" amount="$157.50" />

        <TotalCard label="Daily average" amount="$11.42" />

        <TotalCard label="Savings" amount="$75.00" />

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recent Expenses</Text>
          <Text style={styles.seeAll}>See All</Text>
        </View>

        {/* Expenses List */}
        {expenses.map((expense) => (
          <ExpenseItem
            key={expense.id}
            id={expense.id}
            name={expense.name}
            category={expense.category}
            amount={expense.amount}
            onDelete={handleDeleteExpense}
          />
        ))}

        <TotalCard label="Total expenses" amount={total} />

        <Text style={styles.sectionTitle}>Quick Add Expense</Text>

        <ExpenseForm onAddExpense={addExpense} />

        <Text style={styles.footerText}>
          Track your spending. Build better habits.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#ffffff',
  },

  container: {
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 40,
  },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
  },

  sectionTitle: {
    fontSize: 19,
    fontWeight: '700',
    marginTop: 12,
    marginBottom: 12,
  },

  seeAll: {
    fontSize: 14,
    color: '#666',
  },

  footerText: {
    textAlign: 'center',
    color: '#999',
    fontSize: 12,
    marginTop: 28,
  },
});